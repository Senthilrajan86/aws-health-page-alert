import json
import requests

def lambda_handler(event, context):
   
    slack_webhook_url = "https://hooks.slack.com/services/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"
    
    # Define the message you want to send to Slack
    message = {
        "text": "EventBridge event triggered: " + json.dumps(event)
    }

    try:
        response = requests.post(
            slack_webhook_url,
            data=json.dumps(message),
            headers={'Content-Type': 'application/json'}
        )

        if response.status_code == 200:
            print("Message sent to Slack successfully")
        else:
            print("Failed to send message to Slack")
            print("Response:", response.text)

    except Exception as e:
        print("Error:", str(e))

    return {
        'statusCode': 200,
        'body': json.dumps('Message sent to Slack')
    }

